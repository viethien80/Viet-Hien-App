const express = require('express');
const multer = require('multer');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const schedule = require('node-schedule');
const moment = require('moment-timezone');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.static('public'));
app.use(express.json());

const db = new sqlite3.Database('./db.sqlite');
db.run(`CREATE TABLE IF NOT EXISTS schedules (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, time TEXT, days TEXT, music TEXT)`);

const storage = multer.diskStorage({
  destination: './uploads/',
  filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname))
});
const upload = multer({ storage });

app.post('/upload', upload.single('music'), (req, res) => {
  res.json({ filename: req.file.filename });
});

app.post('/schedule', (req, res) => {
  const { name, time, days, music } = req.body;
  db.run(`INSERT INTO schedules (name, time, days, music) VALUES (?, ?, ?, ?)`, [name, time, days, music]);
  res.json({ success: true });
});

app.get('/schedules', (req, res) => {
  db.all(`SELECT * FROM schedules`, [], (err, rows) => {
    res.json(rows);
  });
});

function runSchedules() {
  db.all(`SELECT * FROM schedules`, [], (err, rows) => {
    rows.forEach(row => {
      const job = schedule.scheduleJob(row.time, () => {
        console.log(`Phát nhạc: ${row.music}`);
      });
    });
  });
}
runSchedules();

app.listen(PORT, () => {
  console.log(`Viet-Hien app running on http://localhost:${PORT}`);
});
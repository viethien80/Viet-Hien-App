document.getElementById("uploadForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const formData = new FormData(e.target);
  const res = await fetch("/upload", { method: "POST", body: formData });
  const data = await res.json();
  alert("Tải thành công: " + data.filename);
});

document.getElementById("save").addEventListener("click", async () => {
  const body = {
    name: document.getElementById("name").value,
    time: document.getElementById("time").value,
    days: Array.from(document.getElementById("days").selectedOptions).map(o => o.value).join(","),
    music: document.getElementById("music").value
  };
  const res = await fetch("/schedule", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  const data = await res.json();
  if (data.success) alert("Đã lưu lịch!");
});